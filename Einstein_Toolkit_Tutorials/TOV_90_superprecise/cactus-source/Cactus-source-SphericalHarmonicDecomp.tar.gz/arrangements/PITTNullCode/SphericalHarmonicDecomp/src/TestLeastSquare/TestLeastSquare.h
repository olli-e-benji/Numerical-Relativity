#ifndef TEST_LEAST_SQUARE_H
#define TEST_LEAST_SQUARE_H

// comment out the following line to test Legendre polynomial
#undef USE_LEGENDRE

#endif
