fp data_0_0;
fp data_p1_0;
fp data_0_p1;
fp data_p1_p1;
