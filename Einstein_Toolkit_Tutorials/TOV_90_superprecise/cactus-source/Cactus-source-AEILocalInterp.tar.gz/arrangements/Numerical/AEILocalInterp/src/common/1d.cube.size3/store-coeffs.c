COEFF(-1) = factor * coeffs->coeff_m1;
COEFF(0) = factor * coeffs->coeff_0;
COEFF(1) = factor * coeffs->coeff_p1;
