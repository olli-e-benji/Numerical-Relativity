      coeffs_dy->coeff_0_0 = x+RATIONAL(-1.0,1.0);
      coeffs_dy->coeff_p1_0 = -x;
      coeffs_dy->coeff_0_p1 = RATIONAL(1.0,1.0)-x;
      coeffs_dy->coeff_p1_p1 = x;
