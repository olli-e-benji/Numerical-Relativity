#ifndef CARPETINTERP_H
#define CARPETINTERP_H

#ifdef __cplusplus
namespace CarpetInterp {
extern "C" {
#endif

/* Scheduled functions */
int CarpetInterpStartup(void);

#ifdef __cplusplus
} /* extern "C" */
} /* namespace CarpetInterp */
#endif

#endif /* !defined(CARPETINTERP_H) */
