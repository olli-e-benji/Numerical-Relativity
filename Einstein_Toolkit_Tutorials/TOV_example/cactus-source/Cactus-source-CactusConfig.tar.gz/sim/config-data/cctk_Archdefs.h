/* Stuff from known architectures */
#ifndef _CCTK_ARCHDEFS_H_
#define _CCTK_ARCHDEFS_H_
#endif /* _CCTK_ARCHDEFS_H_ */
