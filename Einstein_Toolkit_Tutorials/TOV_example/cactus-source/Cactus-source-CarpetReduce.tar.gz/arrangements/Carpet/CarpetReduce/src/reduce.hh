#ifndef CARPETREDUCE_HH
#define CARPETREDUCE_HH

#include "reduce.h"

#endif // !defined(CARPETREDUCE_HH)
